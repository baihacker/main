#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <cctype>
#include <cstddef>
#include <complex>
#include <ctime>
#include <climits>

#include <algorithm>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <deque>
#include <list>
#include <set>
#include <map>
#include <stack>
#include <queue>
#include <bitset>
#include <string>
#include <numeric>
#include <functional>
#include <iterator>
#include <typeinfo>
#include <utility>
#include <memory>

#include <cassert>

#if __cplusplus >= 201103L
#include <tuple>
#include <ratio>
#include <array>
#include <forward_list>
#include <unordered_map>
#include <unordered_set>
#endif
using namespace std;

typedef long long int64;
const int inf = 2000000000;
static inline int Rint()
{
  struct X{ int dig[256]; X(){
  for(int i = '0'; i <= '9'; ++i) dig[i] = 1; dig['-'] = 1;
  }};
  static  X fuck;int s = 1, v = 0, c;
  for (;!fuck.dig[c = getchar()];);
  if (c == '-') s = 0; else if (fuck.dig[c]) v = c ^ 48;
  for (;fuck.dig[c = getchar()]; v = v * 10 + (c ^ 48));
  return s ? v : -v;
}
typedef vector<int> vi;
typedef map<int, int> mii;
typedef set<int> si;

#define all(x) (x).begin(), (x).end()
#define pb push_back
#define mp make_pair
#define sz(x) ((int)(x).size())
#define rep(i, s, e) for (int i = (s); i < (e); ++i)

#if __cplusplus >= 201103L
#define foreach(iter, c) for(auto& iter : c)
#else
#define foreach(itr, c) for(__typeof((c).begin()) itr = (c).begin(); itr != (c).end(); ++itr)
#endif

template<typename T> static inline void cmax(T& a, const T& b){if(b>a)a=b;}
template<typename T> static inline void cmin(T& a, const T& b){if(b<a)a=b;}
#define SL static inline

#define dbg(x) cerr << (#x) << " = " << (x) << endl

const int maxn = 100005;
const int64 mod = 1000000007;

int mat[16][16];
int data[3][16][16];

void dfs(int row, int start, int mask, int next)
{
  if (row == 4)
  {
    ++mat[next][start];
    return;
  }
  const int f = 1 << row;
  if (mask & f)
  {
    dfs(row+1, start, mask, next);
  }
  else
  {
    if ((next & f) == 0)
    {
      mask ^= f;
      next ^= f;
      dfs(row+1, start, mask, next);
      mask ^= f;
      next ^= f;
    }
    if (row + 1 < 4 && (mask & (f << 1)) == 0)
    {
      mask ^= f;
      mask ^= f << 1;
      dfs(row+1, start, mask, next);
      mask ^= f;
      mask ^= f << 1;
    }
  }
}

void init()
{
  for (int i = 0; i < 16; ++i)
  {
    dfs(0, i, i, 0);
  }
  for (int i = 0; i < 16;puts(""), ++i)
  for (int j = 0; j < 16; ++j)
  cerr << mat[i][j] << " ";
}
int solve(int n)
{
  if (n == 1)
  {
    return 1;
  }

  int (*m)[16] = data[0];
  int (*r)[16] = data[1];
  int (*t)[16] = data[2];
  memcpy(m, mat, sizeof data[0]);
  
  //for (int i = 0; i < 16; ++i)
  //r[i][0] = 0;
  //r[0][0] = 1;
  
  // init x[0]
  for (int i = 0; i < 16; ++i)
  {
    r[i][0] = m[i][0];
    m[i][0] = 0;
  }
  for (--n; n; n >>= 1)
  {
    if (n & 1)
    {
      for (int i = 0; i < 16; ++i)
      {
        int64 s = 0;
        for (int k = 0; k < 16; ++k)
        s += (int64)m[i][k] * r[k][0] % mod;
        t[i][0] = s % mod;
      }
      swap(r, t);
    }
    for (int i = 0; i < 16; ++i)
    for (int j = 0; j < 16; ++j)
    {
      int64 s = 0;
      for (int k = 0; k < 16; ++k)
      s += (int64)m[i][k] * m[k][j] % mod;
      t[i][j] = s % mod;
    }
    swap(m, t);
  }
  return r[0][0];
}
// the answer is : 1 4 2 3 2 3 2 3 ...
int answer[] = {1, 1, 4, 2, 3};
static inline int solve_fast(int n)
{
  if (n <= 4) return answer[n];
  return n & 1 ? 2 : 3;
}
int main()
{
  //init();
  int T = Rint();
  assert(T >= 1 && T <= 3000);
  while (T--)
  {
    const int n = Rint();
    assert(n >= 1 && n <= 1000000000);
    printf("%d\n", solve_fast(n));
  }
  return 0;
}