#include <cstdio>
#include <iostream>
#include <cstring>
#include <cmath>
#include <map>
#include <algorithm>
using namespace std;
typedef long long ll;

int T, n;

int solve()
{
    if (n == 1) return 1;
    if (n % 2 == 1) return 2;
    if (n == 2) return 4;
    return 3;
}

int main()
{
    scanf("%d", &T);
    while (T--)
    {
        scanf("%d", &n);
        printf("%d\n", solve());
    }
    return 0;
}
