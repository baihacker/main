#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <map>
#include <string>
#include <iostream>
#include <cassert>
#include <cctype>
#include <set>
using namespace std;

bool enable_log;

enum
{
  REPLACED_NODE,    // 拥有replace字段指向其它结点
  TYPE_VARIABLE_NODE, // 当input和output不为空时为一个函数类型变量,否则为普通类型变量
  TYPE_CONSTANT_NODE, // 类型常量:Int, String等
};
struct TypeDetail
{
  TypeDetail() : node_type(TYPE_VARIABLE_NODE){}
  int node_type;
  string input;
  string output;
  string constant_name;
  string replace;
};
enum
{
  NORMAL_EXPRESSION,
  INTEGER_EXPRESSION,
  STRING_EXPRESSION,
};
struct ExpressionNode
{
  ExpressionNode():expression_type(NORMAL_EXPRESSION){}
  ~ExpressionNode()
  {
    const int n = children.size();
    for (int i = 0; i < n; ++i) delete children[i];
  }
  int expression_type;
  vector<ExpressionNode*> children;
  string name;
};

struct ExpressionParser
{
ExpressionParser() : id(0){}
~ExpressionParser(){}

void show_expression_tree(ExpressionNode* root)
{
  if (root->children.size())
  {
    cerr << "(";
    show_expression_tree(root->children[0]);
    cerr << " " << root->name << " ";
    show_expression_tree(root->children[1]);
    cerr << ")";
  }
  else
  {
    cerr << root->name;
  }
}
ExpressionNode* parse(const string& rep)
{
  int curr = 0;
  return parse_expression0(rep, curr);
}

private:
ExpressionNode* parse_expression0(const string& rep, int& curr)
{
  const int n = rep.size();

  ExpressionNode* ret = parse_expression1(rep, curr);
  for (;;)
  {
    ExpressionNode* t = parse_expression1(rep, curr);
    if (t == NULL) break;
    ExpressionNode* temp = new ExpressionNode();
    temp->name = next_node_name();
    temp->children.push_back(ret);
    temp->children.push_back(t);
    ret = temp;
  }
  return ret;
}

ExpressionNode* parse_expression1(const string& rep, int& curr)
{
  const int n = rep.size();
  while (curr < n && rep[curr] == ' ') ++curr;
  if (curr == n) return NULL;
  
  if (rep[curr] == '(')
  {
    ++curr;
    ExpressionNode* tmp = parse_expression0(rep, curr);
    while (rep[curr] != ')') ++curr;
    ++curr;
    return tmp;
  }
  else if (rep[curr] == ')')
  {
    return NULL;
  }
  else
  {
    string name;
    while (curr < n && (isdigit(rep[curr]) || isalpha(rep[curr])) ) name+=rep[curr++];
    ExpressionNode* ret = new ExpressionNode();
    ret->name = name;
    ret->expression_type = isdigit(name[0]) ? INTEGER_EXPRESSION : NORMAL_EXPRESSION;
    return ret;
  }
  return NULL;
}
string next_node_name()
{
  char buff[256];
  sprintf(buff, "e%d", id++);
  return buff;
}
private:
int id;
};
struct Context
{
Context() : next_node_id_(0)
{
}
~Context(){}

static Context GetBasicContext()
{
  Context ret;
  ret.new_TypeNode("Int");
  ret.type_graph_["Int"].node_type = TYPE_CONSTANT_NODE;
  ret.type_graph_["Int"].constant_name = "Int";
  
  ret.new_TypeNode("String");
  ret.type_graph_["String"].node_type = TYPE_CONSTANT_NODE;
  ret.type_graph_["String"].constant_name = "String";
  
  ret.new_TypeNode("add");
  ret.type_graph_["add"].input = "Int";
  ret.type_graph_["add"].output = "add_internal";
  
  ret.new_TypeNode("add_internal");
  ret.type_graph_["add_internal"].input = "Int";
  ret.type_graph_["add_internal"].output = "Int";
  
  ret.named_type_set_.insert("Int");
  ret.named_type_set_.insert("String");
  ret.named_type_set_.insert("add");
  
  return ret;
}

// 添加匿名结点
string new_TypeNode()
{
  char buff[256];
  sprintf(buff, "z%d", ++next_node_id_);
  
  TypeDetail d;
  d.node_type = TYPE_VARIABLE_NODE;
  type_graph_[buff] = d;
  
  return buff;
}

// 添加命名结点
string new_TypeNode(const string& name)
{
  assert(type_graph_.count(name) == 0);
  
  TypeDetail d;
  d.node_type = TYPE_VARIABLE_NODE;
  type_graph_[name] = d;
  
  named_type_set_.insert(name);
  
  return name;
}

// 添加匿名函数结点
string new_TypeNode(const string& input, const string& output)
{
  char buff[256];
  sprintf(buff, "i%d", ++next_node_id_);
  
  TypeDetail d;
  d.node_type = TYPE_VARIABLE_NODE;
  d.input = type_graph_.count(input) == 0 ? new_TypeNode(input) : input;
  d.output = type_graph_.count(output) == 0 ? new_TypeNode(output) : output;
  type_graph_[buff] = d;
  
  return buff;
}

// 添加命名函数结点
string new_TypeNode(const string& name, const string& input, const string& output)
{
  assert(type_graph_.count(name) == 0);
  
  TypeDetail d;
  d.node_type = TYPE_VARIABLE_NODE;
  d.input = type_graph_.count(input) == 0 ? new_TypeNode(input) : input;
  d.output = type_graph_.count(output) == 0 ? new_TypeNode(output) : output;
  type_graph_[name] = d;
  
  named_type_set_.insert(name);
  
  return name;
}

bool has_node(const string& x) const
{
  return type_graph_.count(x) > 0;
}

bool is_named(const string& x) const
{
  return named_type_set_.count(x) > 0;
}

string find_replaced(const string& x)
{
  if (type_graph_.count(x) == 0) return "";
  for (string now = x;;)
  {
    map<string, TypeDetail>::iterator where = type_graph_.find(now);
    assert(where != type_graph_.end());
    const TypeDetail& TypeDetail = where->second;
    if (TypeDetail.node_type != REPLACED_NODE)
    {
      return now;
    }
    if (TypeDetail.replace.empty())
    {
      cerr << "find REPLACED Node, but the replace field is empty" << endl;
      assert(0);
    }
    now = TypeDetail.replace;
  }
  return "";
}

string copy_node_from(Context& other, const string& name, int keep_name=0)
{
  if (keep_name)
  {
    if (has_node(name))
    {
      cerr << "can not copy node : duplicate name" << endl;
      return "";
    }
  }
  map<string, string> rename;
  string ret = copy_node_from_impl(other, name, rename);
  if (keep_name)
  {
    new_TypeNode(name);
    type_graph_[name].node_type = REPLACED_NODE;
    type_graph_[name].replace = ret;
    ret = name;
  }
  return ret;
}

string copy_node_from_impl(Context& other, const string& name, map<string, string>& rename)
{
  string real_name = other.find_replaced(name);
  assert(!real_name.empty());
  if (rename.count(real_name)) return rename[real_name];
  
  map<string, TypeDetail>::iterator where = other.type_graph_.find(real_name);
  assert(where!=other.type_graph_.end());
  
  TypeDetail detail = where->second;
  if (!detail.input.empty())
  {
    detail.input = copy_node_from_impl(other, detail.input, rename);
    assert(!detail.input.empty());
  }
  if (!detail.output.empty())
  {
    detail.output = copy_node_from_impl(other, detail.output, rename);
    assert(!detail.output.empty());
  }
  
  string new_node = new_TypeNode();
  type_graph_[new_node] = detail;
  rename[real_name] = new_node;
  
  return new_node;
}

bool set_match(const string& a, const string& b)
{
  if (a == b) return true;
  string aa = find_replaced(a);
  string bb = find_replaced(b);
  map<string, TypeDetail>::iterator ia = type_graph_.find(aa);
  map<string, TypeDetail>::iterator ib = type_graph_.find(bb);
  assert(ia != type_graph_.end());
  assert(ib != type_graph_.end());
  if (ia == ib) return true;
  
  if (ia->second.input.empty() && ib->second.input.empty())
  {// 两个叶子结点
  
    // 其中一个是常量
    if (!ia->second.constant_name.empty())
    {
      if (ib->second.constant_name.empty())
      {
        ib->second.constant_name = ia->second.constant_name;
        ib->second.node_type = TYPE_CONSTANT_NODE;
      }
      else
      {
        assert(ib->second.constant_name == ia->second.constant_name);
      }
    }
    else if (!ib->second.constant_name.empty())
    {
      ia->second.constant_name = ib->second.constant_name;
      ia->second.node_type = TYPE_CONSTANT_NODE;
    }
    // 两者都是变量时让其中一个指向另一个
    else if (a < b)
    {
      ia->second.node_type = REPLACED_NODE;
      ia->second.replace = bb;
    }
    else
    {
      ib->second.node_type = REPLACED_NODE;
      ib->second.replace = aa;
    }
  }
  else if (!ia->second.input.empty() && ib->second.input.empty())
  {// a的类型展开,b的没有展开
    if (!ib->second.constant_name.empty())
    {
      cerr << "Constant can not be function" << endl;
      return false;
    }
    ib->second.node_type = REPLACED_NODE;
    ib->second.replace = aa;
  }
  else if (ia->second.input.empty() && !ib->second.input.empty())
  {
    if (!ia->second.constant_name.empty())
    {
      cerr << "Constant can not be function" << endl;
      return false;
    }
    ia->second.node_type = REPLACED_NODE;
    ia->second.replace = bb;
  }
  else
  {
    std::string u = ia->second.input;
    std::string v = ib->second.input;
    std::string u0 = ia->second.output;
    std::string v0 = ib->second.output;
    bool ret = set_match(u, v);
    ret = ret && set_match(u0, v0);
    return ret;
  }
  return true;
}

string get_dsp_name(map<string, string>& dsp_name, TypeDetail& detail, const string& name, const string& to_t)
{
  if (!detail.constant_name.empty()) return detail.constant_name;
  if (name == to_t) return "t";
  map<string, string>::iterator where = dsp_name.find(name);
  if (where != dsp_name.end()) return where->second;
  char buff[256];
  sprintf(buff, "t%d", dsp_name.size()+1);
  return dsp_name[name] = buff;
}

string find_ret_type(const string& x)
{
  for (string now = find_replaced(x); ;)
  {
    if (now.empty()) return "";
    if (!type_graph_[now].constant_name.empty()) return now;
    if (!type_graph_[now].output.empty()) now = find_replaced(type_graph_[now].output);
    else return now;
  }
}

void display(const string& x, int depth=0, int is_left=0)
{
  map<string, string> dsp_name;
  string ret_type = find_ret_type(x);
  display(x, dsp_name, ret_type);
}

void display(const string& x, map<string, string>& dsp_name, const string& to_t, int depth=0, int is_left=0)
{
  string s = find_replaced(x);
  map<string, TypeDetail>::iterator where = type_graph_.find(s);
  assert(where != type_graph_.end());
  if (where->second.input.empty())
  {
    cout << get_dsp_name(dsp_name, where->second, s, to_t);
  }
  else
  {
    if(depth&&is_left) cout << "(";
    display(where->second.input, dsp_name, to_t, depth+1, 1);
    cout << " -> ";
    display(where->second.output, dsp_name, to_t, depth+1, 0);
    if(depth&&is_left) cout << ")";
  }
}

private:
int next_node_id_;
map<string, TypeDetail> type_graph_;
set<string> named_type_set_;
};


/*
  解析表达式树,返回对应的类型结点
  rename:   形参重命名
  reference:  参考上下文
*/
string parse_expression_tree(ExpressionNode* root, map<string, string>& rename, Context& reference, Context& output)
{
  if (root->children.size())
  {
    string left_type = parse_expression_tree(root->children[0], rename, reference, output);
    string right_type = parse_expression_tree(root->children[1], rename, reference, output);

    if (left_type.empty() || right_type.empty()) return "";
    
    // 本结点对应的类型
    string self_type = output.new_TypeNode();
    // rule : right_type - > self_type;
    string test = output.new_TypeNode(right_type, self_type);
    // left_type 和 temp1等价
    output.set_match(left_type, test);

    return self_type;
  }
  else
  {
    // 形参重命名
    string real_name = root->name;
    if (rename.count(root->name)) real_name = rename[root->name];
    
    // 在图中已经有该结点
    if (output.has_node(real_name)) return real_name;
    
    // 整数:在参考的上下文中定义
    if (root->expression_type == INTEGER_EXPRESSION)
    {
      real_name = "Int";
    }
    
    // 名字应该在参考的上下文中
    if (!reference.has_node(real_name))
    {
      cerr << "Undeclared name : " << root->name << endl;
      return "";
    }
    
    return output.copy_node_from(reference, real_name);
  }
}


string parse_function(Context& context, Context& reference, const string& rep, string& ret_type_node);
string parse_function(Context& context, Context& reference, const string& function_name, const vector<string>& parameter, const string& rep, string& ret_type_node);
string parse_function(Context& context, Context& reference, const string& rep)
{
  if (enable_log)
  cerr << "Parse function : " << rep << endl;
  string ret_type_node;
  string function_name = parse_function(context, reference, rep, ret_type_node);
  if (enable_log)
  {
    if (!function_name.empty())
    {
      cerr << "Result:" << endl;
      context.display(function_name);
      cout << endl;
      return function_name;
    }
    else
    {
      cerr << "ParseFailed" << endl;
    }
  }
  return function_name;
}

string parse_function(Context& context, Context& reference, const string& rep, string& ret_type_node)
{
  string temp = rep;
  const int n = temp.size();
  int eq = 0;
  while (eq < n && temp[eq] != '=') ++eq;
  if (eq == n)
  {
    if (enable_log) cerr << "Can not find =" << endl;
    return "";
  }
  temp[eq] = 0;
  string name;
  vector<string> parameter;
  for (char* x = strtok(&temp[0], " "); x; x = strtok(NULL, " "))
  {
    if (name.empty()) name = x;
    else parameter.push_back(x);
  }
  if (enable_log)
  {
    cerr << "Function = " << name << endl;
    cerr << "Parameters =";
    for (int i = 0; i < parameter.size(); ++i)
    cerr << " " <<parameter[i];
    cerr << endl;
    cerr << "Expression = " << rep.substr(eq+1) << endl;
  }
  return parse_function(context, reference, name, parameter, rep.substr(eq+1), ret_type_node);
}

string parse_function(Context& context, Context& reference, const string& function_name, const vector<string>& parameter, const string& rep, string& ret_type_node)
{
  if (context.has_node(function_name)) return function_name;
  
  // 在上下文中添加形参,表达式解析中会引用这些结点
  // 对形参进行重命名
  map<string, string> arg2internal;
  const int n = parameter.size();
  for (int i = 0; i < n; ++i)
  {
    arg2internal[parameter[i]] = context.new_TypeNode();
  }
  
  // 在上下文中添加函数自己,在递归调用时会引用这个结点
  context.new_TypeNode(function_name);

  // 解析右端的表达式
  ExpressionParser ep;
  ExpressionNode* et = ep.parse(rep);
  if (enable_log)
  {
    cerr << "Syntax tree:" << endl;
    ep.show_expression_tree(et); cerr << endl;
  }
  
  // 类型匹配
  string result = parse_expression_tree(et, arg2internal, reference, context);
  delete et;
  if (!result.empty())
  {
    // 和函数参数匹配
    string temp_f = context.new_TypeNode();
    string last = temp_f;
    for (int i = 0; i < n; ++i)
    {
      string temp = context.new_TypeNode();
      string test = context.new_TypeNode(arg2internal[parameter[i]], temp);
      context.set_match(last, test);
      last = temp;
    }
    // 右端的返回类型是函数的返回类型
    context.set_match(result, last);
    // 临时函数的形状
    context.set_match(function_name, temp_f);
    ret_type_node = context.find_replaced(last);
    return function_name;
  }
  return "";
}

char line[1024];
int main()
{
  enable_log = false;
  int T; scanf("%d", &T);
  assert(T<=10);
  for (int id = 1; id <= T; ++id)
  {
    Context ref = Context::GetBasicContext();
    int cnt; scanf("%d", &cnt);
    while (getchar() != '\n');
    printf("Case %d:\n", id);
    for (int l = 0; l < cnt; ++l)
    {
      Context out;
      gets(line);
      //puts(line);
      //fflush(stdout);
      string fun = parse_function(out, ref, line);
      ref.copy_node_from(out, fun, 1);
      cout << line << endl;
      ref.display(fun);
      cout << endl;
    }
    cout << endl;
  }

  return 0;
}