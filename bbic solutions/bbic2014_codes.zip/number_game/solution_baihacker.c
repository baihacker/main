#include <cstdio>
#include <cassert>
#include <algorithm>
#include <numeric>
#include <iostream>
using namespace std;
static inline int Rint()
{
     struct X{ int dig[256]; X(){
     for(int i = '0'; i <= '9'; ++i) dig[i] = 1; dig['-'] = 1;
     }};
     static     X fuck;int s = 1, v = 0, c;
     for (;!fuck.dig[c = getchar()];);
     if (c == '-') s = 0; else if (fuck.dig[c]) v = c ^ 48;
     for (;fuck.dig[c = getchar()]; v = v * 10 + (c ^ 48));
     return s ? v : -v;
}

int data[10000];
int ps[10000];
int dp[10000][100];

int main()
{
  int T = Rint();
  assert(T >= 1 && T <= 15);
  while (T--)
  {
    const int N = Rint(), Q = Rint();
    assert(N >= 1 && N <= 100);
    assert(Q >= 1 && Q <= 10000);
    for (int i = 0; i < N; ++i)
    {
      data[i] = Rint();
      assert(data[i] >= 0 && data[i] < 1000);
    }
    for (int i = N; i < 10000; ++i)
    {
      data[i] = data[i-N];
    }
    partial_sum(data, data+10000, ps);
    
    for (int i = 0; i < N; ++i)
    {
      dp[i][i] = data[i];
      for (int j = i - 1; j >= 0; --j)
      {
        const int u = data[i] - dp[i-1][j];
        const int v = data[j] - dp[i][j+1];
        dp[i][j] = max(u, v);
      }
    }
    for (int i = N; i < 10000; ++i)
    {
      const int val = data[i];
      {
        const int u = val - dp[i-1][N-1];
        const int v = data[N-1] - dp[i-N][0];
        dp[i][N-1] = max(u, v);
      }
      for (int j = N-2; j >= 0; --j)
      {
        const int u = val - dp[i-1][j];
        const int v = data[j] - dp[i][j+1];
        dp[i][j] = max(u, v);
      }
    }
    for (int id = 0; id < Q; ++id)
    {
      int l = Rint(), r = Rint();
      assert(0 <= l && l <= r && r < 10000);
      int s = ps[r];
      if (l > 0) s -= ps[l-1];
      const int d = r - l;
      l %= N;
      r = l + d;
      const int temp = s + dp[r][l];
      assert(temp % 2 == 0);
      printf("%d\n", temp >> 1);
    }
  }
}