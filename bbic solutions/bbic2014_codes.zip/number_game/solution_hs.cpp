#include <cstdio>
#include <iostream>
#include <cstring>
#include <cmath>
#include <map>
#include <algorithm>
using namespace std;
typedef long long ll;

const int maxn = 105;
const int maxm = 10005;
int T;
int n, q;
int a[maxn];
int l, r;
int dp[maxn][maxm], s[maxn][maxm];

int main()
{
    scanf("%d", &T);
    while (T--)
    {
        scanf("%d%d", &n, &q);
        for (int i=0;i<n;i++) scanf("%d", &a[i]);

        for (int i=0;i<n;i++)
        {
            s[i][i] = a[i%n];
            for (int j=i+1;j<=10000;j++)
                s[i][j] = s[i][j-1] + a[j%n];
        }

        for (int i=0;i<n;i++) dp[i][i] = a[i];
        for (int l=1;l<=10000;l++)
            for (int i=0;i<n&&i+l<=10000;i++)
            {
                int j = i + l;
                if (i == n-1) dp[i][j] = s[i][j] - min(dp[0][j-n], dp[i][j-1]);
                else dp[i][j] = s[i][j] - min(dp[i+1][j], dp[i][j-1]);
            }

        while (q--)
        {
            scanf("%d%d", &l, &r);
            int d = l / n;
            l -= d * n; r -= d * n;
            printf("%d\n", dp[l][r]);
        }
    }
    return 0;
}
