#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <cassert>
using namespace std;
typedef long long int64;
const int mod = 1000000007;
static inline int Rint()
{
     struct X{ int dig[256]; X(){
     for(int i = '0'; i <= '9'; ++i) dig[i] = 1; dig['-'] = 1;
     }};
     static     X fuck;int s = 1, v = 0, c;
     for (;!fuck.dig[c = getchar()];);
     if (c == '-') s = 0; else if (fuck.dig[c]) v = c ^ 48;
     for (;fuck.dig[c = getchar()]; v = v * 10 + (c ^ 48));
     return s ? v : -v;
}
static inline int add(int x, int y){x+=y;if(x>=mod) x-=mod;return x;}
static inline int mul(int x, int y){int64 t = (int64)x*y; return t % mod;}

const int maxn = 100005;
int data[maxn];
int dp[maxn][2];

int solve(int n)
{
  int ret = 0;
  for (;;)
  {
    sort(data, data+n);
    int flag = 1, mv = data[n-1], start = -1;
    if (mv == 0)
    {
      ret = add(ret, 1);
      break;
    }
    {
      while (flag <= mv) flag <<= 1;
      flag >>= 1;
    }
    dp[0][0] = data[0] >= flag ? flag : data[0] + 1;
    dp[0][1] = data[0] >= flag ? data[0] - flag + 1 : 0;
    if (data[0] & flag) start = 0;
    for (int i = 1; i < n; ++i)
    {
      int ones = data[i] >= flag ? data[i] - flag + 1 : 0;
      int zeros = data[i] >= flag ? flag : data[i] + 1;
      dp[i][0] = add(mul(dp[i-1][0], zeros), mul(dp[i-1][1], ones));
      dp[i][1] = add(mul(dp[i-1][0], ones), mul(dp[i-1][1], zeros));
      if (start == -1 && (data[i]&flag)) start = i;
    }
    int dest = 0, extra = 1;
    for (int i = n - 1; i > start; --i)
    {
      ret = add(ret, mul(dp[i-1][dest], extra));
      data[i] ^= flag;
      extra = mul(extra, data[i]+1);
      dest ^= 1;
    }
    if (dest == 0)
    {
      if (start > 0)
      ret = add(ret, mul(dp[start-1][0], extra));
      else
      ret = add(ret, extra);
      break;
    }
    else
    {
      data[start] ^= flag;
    }
  }
  return ret;
}
int main()
{
  int T = Rint();
  int n;
  assert(T <= 150);
  while (T-- && scanf("%d", &n) == 1)
  {
    assert(n >= 1 && n <= 100000);
    for (int i = 0; i < n; ++i)
    {
      data[i] = Rint();
      assert(data[i] >= 0 && data[i] < 1000000);
    }
    printf("%d\n", solve(n));
  }
  return 0;
}