#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <cctype>
#include <cstddef>
#include <complex>
#include <ctime>
#include <climits>

#include <algorithm>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <deque>
#include <list>
#include <set>
#include <map>
#include <stack>
#include <queue>
#include <bitset>
#include <string>
#include <numeric>
#include <functional>
#include <iterator>
#include <typeinfo>
#include <utility>
#include <memory>

#include <cassert>

using namespace std;

typedef long long int64;
const int inf = 2000000000;
static inline int Rint()
{
	struct X{ int dig[256]; X(){
	for(int i = '0'; i <= '9'; ++i) dig[i] = 1; dig['-'] = 1;
	}};
	static 	X fuck;int s = 1, v = 0, c;
	for (;!fuck.dig[c = getchar()];);
	if (c == '-') s = 0; else if (fuck.dig[c]) v = c ^ 48;
	for (;fuck.dig[c = getchar()]; v = v * 10 + (c ^ 48));
	return s ? v : -v;
}


template<typename T> static inline void cmax(T& a, const T& b){if(b>a)a=b;}
template<typename T> static inline void cmin(T& a, const T& b){if(b<a)a=b;}
#define SL static inline
#define pb push_back
#define mp make_pair
#define dbg(x) cerr << (#x) << " = " << (x) << endl

const int maxp = 1000000;
static int pcnt;
static int plist[maxp/10];
static int pmask[maxp+1];
SL void init_primes()
{
    pcnt = 0;
    for (int i = 1; i <= maxp; ++i) pmask[i] = i;
    for (int i = 2; i <= maxp; ++i)
    {
        if (pmask[i] == i)
        {
            plist[pcnt++] = i;
        }
        for (int j = 0; j < pcnt; ++j)
        {
            const int64 t = (int64)plist[j] * i;
            if (t > maxp) break;
            pmask[t] = plist[j];
            if (i % plist[j] == 0)
            {
                break;
            }
        }
    }
}
SL vector<pair<int64, int> > factorize(int64 n)
{
    vector<pair<int64, int> > ret;
    if (n <= 1)
    {
        return ret;
    }

    if (n <= maxp)
    {
        while (n != 1)
        {
            int now = pmask[n];
            int c = 0;
            while (n % now == 0) n /= now, ++c;
            if (c) ret.push_back(mp((int64)now, c));
        }
    }
    else
    {
        for (int i = 0; i < pcnt; ++i)
        {
            const int64 p = plist[i];
            const int64 test = p * p;
            if (test > n) break;
            int c = 0;
            while (n % p == 0) n /= p, ++c;
            if (c) ret.push_back(mp(p, c));
        }
        if (n != 1) ret.push_back(mp(n, 1));
    }
    return ret;
}
void get_factors_impl(const int limit, const vector<pair<int64, int> >& f, int64 value, vector<int64>& result)
{
    result.push_back(value);
    for (int i = 0; i < limit; ++i)
    {
        int64 tvalue = value;
        const int64 p = f[i].first;
        const int c = f[i].second;
        for (int j = 1; j <= c; ++j)
        {
            tvalue *= p;
            get_factors_impl(i, f, tvalue, result);
        }
    }
}

SL vector<int64> get_factors(const vector<pair<int64, int> >& f)
{
    vector<int64> result;
    get_factors_impl(static_cast<int>(f.size()), f, 1, result);
    return result;
}

SL vector<int64> get_factors(int64 value)
{
    vector<int64> result;
    if (value <= 1)
    {
        result.push_back(1);
        return result;
    }
    vector<pair<int64, int> > f = factorize(value);
    get_factors_impl(static_cast<int>(f.size()), f, 1, result);
    return result;
}

SL int64 power_mod(int64 x, int64 n, int64 mod)
{
    int64 ret = 1;
    x %= mod;
    if (x < 0) x += mod;
    for (; n; n >>= 1)
    {
        if (n&1) ret = ret * x % mod;
        x = x * x % mod;
    }
    return ret;
}

SL int find_deg(int n, int m, const vector<int64>& factors)
{
  const int size = factors.size();
  for (int i = 0; i < size; ++i)
  {
    if (power_mod(n, factors[i], m) == 1)
    {
      return factors[i];
    }
  }
  assert(0);
  return 0;
}

int main()
{
  init_primes();
  int T = Rint();
  assert(T >= 1 && T<=1000);
  for (int id0 = 0; id0 < T; ++id0)
  {
    const int M = Rint(), Q = Rint();
    assert(M >= 1 && M <= 1000000000);
    assert(Q >= 1 && Q <= 200);

    for (int id1 = 0; id1 < Q; ++id1)
    {
      const int A = Rint();
      set<int> s;
      for (int now = A;;)
      {
        if (s.count(now)) break;
        s.insert(now);
        now = (int64)now * A % M;
      }
      printf("%d\n", s.size());
    }
  }
  cerr << clock() << endl;
  return 0;
}