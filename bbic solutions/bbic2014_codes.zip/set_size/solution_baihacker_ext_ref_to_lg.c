#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <cctype>
#include <cstddef>
#include <complex>
#include <ctime>
#include <climits>

#include <algorithm>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <deque>
#include <list>
#include <set>
#include <map>
#include <stack>
#include <queue>
#include <bitset>
#include <string>
#include <numeric>
#include <functional>
#include <iterator>
#include <typeinfo>
#include <utility>
#include <memory>

#include <cassert>

using namespace std;

typedef long long int64;
const int inf = 2000000000;
static inline int Rint()
{
  struct X{ int dig[256]; X(){
  for(int i = '0'; i <= '9'; ++i) dig[i] = 1; dig['-'] = 1;
  }};
  static  X fuck;int s = 1, v = 0, c;
  for (;!fuck.dig[c = getchar()];);
  if (c == '-') s = 0; else if (fuck.dig[c]) v = c ^ 48;
  for (;fuck.dig[c = getchar()]; v = v * 10 + (c ^ 48));
  return s ? v : -v;
}


template<typename T> static inline void cmax(T& a, const T& b){if(b>a)a=b;}
template<typename T> static inline void cmin(T& a, const T& b){if(b<a)a=b;}
#define SL static inline
#define pb push_back
#define mp make_pair
#define dbg(x) cerr << (#x) << " = " << (x) << endl

const int maxp = 1000000;
static int pcnt;
static int plist[maxp/10];
static int pmask[maxp+1];
SL void init_primes()
{
    pcnt = 0;
    for (int i = 1; i <= maxp; ++i) pmask[i] = i;
    for (int i = 2; i <= maxp; ++i)
    {
        if (pmask[i] == i)
        {
            plist[pcnt++] = i;
        }
        for (int j = 0; j < pcnt; ++j)
        {
            const int64 t = (int64)plist[j] * i;
            if (t > maxp) break;
            pmask[t] = plist[j];
            if (i % plist[j] == 0)
            {
                break;
            }
        }
    }
}
SL vector<pair<int64, int> > factorize(int64 n)
{
    vector<pair<int64, int> > ret;
    if (n <= 1)
    {
        return ret;
    }

    if (n <= maxp)
    {
        while (n != 1)
        {
            int now = pmask[n];
            int c = 0;
            while (n % now == 0) n /= now, ++c;
            if (c) ret.push_back(mp((int64)now, c));
        }
    }
    else
    {
        for (int i = 0; i < pcnt; ++i)
        {
            const int64 p = plist[i];
            const int64 test = p * p;
            if (test > n) break;
            int c = 0;
            while (n % p == 0) n /= p, ++c;
            if (c) ret.push_back(mp(p, c));
        }
        if (n != 1) ret.push_back(mp(n, 1));
    }
    return ret;
}

SL int64 power_mod(int64 x, int64 n, int64 mod)
{
    int64 ret = 1;
    x %= mod;
    if (x < 0) x += mod;
    for (; n; n >>= 1)
    {
        if (n&1) ret = ret * x % mod;
        x = x * x % mod;
    }
    return ret;
}

int fil(int n, int a)
{
  for (int d = __gcd(n, a); d > 1; d = __gcd(n, a)) n /= d;
  return n;
}

SL int find_deg(int n, int m, int phi, const vector<pair<int64, int> >& fphi)
{
  int ret = phi;
  const int size = fphi.size();
  for (int i = 0; i < size; ++i)
  {
    const int p = fphi[i].first;
    while (ret % p == 0 && power_mod(n, ret / p, m) == 1)
    {
      ret /= p;
    }
  }
  return ret;
}

SL int find_deg(int n, int m, int phi, const vector<int>& fphi)
{
  int ret = phi;
  const int size = fphi.size();
  for (int i = 0; i < size; ++i)
  {
    const int p = fphi[i];
    while (ret % p == 0 && power_mod(n, ret / p, m) == 1)
    {
      ret /= p;
    }
  }
  return ret;
}

int main()
{
  init_primes();
  int T = Rint();
  assert(T >= 1 && T<=1000);
  for (int id0 = 0; id0 < T; ++id0)
  {
    const int M = Rint(), Q = Rint();
    assert(M >= 1 && M <= 1000000000);
    assert(Q >= 1 && Q <= 200);
    vector<pair<int64, int> > f = factorize(M);

    vector<int64> pre;
    const int fsize = f.size();
    int phi_M = M;
    for (int i = 0; i < fsize; ++i)
    {
      phi_M -= phi_M / f[i].first;
    }
    vector<pair<int64, int> > fphi = factorize(phi_M);
    
    for (int id1 = 0; id1 < Q; ++id1)
    {
      const int A = Rint();
      assert(A >= 0 && A < M);
      if (A <= 1 || M == 1) {puts("1"); continue;}
      
      const int N1 = fil(M, A);
      const int N0 = M / N1;
      int c = 0;
      for (int a = A % N0; a; a = (int64)a * A % N0) ++c;
      #if 1
        vector<int> vec;
        int phi_N1 = N1;
        {
          const int size = f.size();
          for (int i = 0; i < size; ++i)
          if (phi_N1 % f[i].first == 0)
          {
            phi_N1 -= phi_N1 / f[i].first;
          }
        }
        {
          const int size = fphi.size();
          for (int i = 0; i < size; ++i)
          if (phi_N1 % fphi[i].first == 0)
          {
            vec.pb(fphi[i].first);
          }
        }
        c += find_deg(A, N1, phi_N1, vec);
      #else
        vector<pair<int64, int> > fN1 = factorize(N1);
        int phi_N1 = N1;
        for (int i = 0; i < fN1.size(); ++i)
        phi_N1 -= phi_N1 / fN1[i].first;
        c += find_deg(A, N1, phi_N1, factorize(phi_N1));
      #endif
      printf("%d\n", c);
    }
  }
  cerr << clock() << endl;
  return 0;
}