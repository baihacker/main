
#include <cassert>
#include <cstdio>
#include <map>

int highbit(int x) {
  for (; x & (x - 1); x &= x - 1);
  return x;
}

int gcd(int a, int b) {
  return b ? gcd(b, a % b) : a;
}

int fil(int n, int a) {
  for (int d = gcd(n, a); d > 1; d = gcd(n, a)) n /= d;
  return n;
}

int expo(int b, int e, int m) {
  int a = 1;
  for (int l = highbit(e); l; l >>= 1) {
    a = (long long) a * a % m;
    if (l & e) a = (long long) a * b % m;
  }
  return a;
}

int euler_totient(int n) {
  int e = n;
  for (int i=2; i * i <= n; ++i)
    if (n % i == 0) {
      e -= e / i;
      for (n /= i; n % i == 0; n /= i);
    }
  return n > 1 ? e - e / n : e;
}

int factors(int n, int* p) {
  int h = 0;
  for (int i=2; i * i <= n; ++i)
    if (n % i == 0) {
      p[h++] = i;
      for (n /= i; n % i == 0; n /= i);
    }
  if (n > 1) p[h++] = n;
  return h;
}

struct order{
  const int n;
  const int phi;
  int h;
  int p[10];

  order(int n): n(n), phi(euler_totient(n)) {
    h = factors(phi, p);
  }

  int operator()(int a) const {
    int g = phi;
    for (int i=0; i < h; ++i) {
      while (g % p[i] == 0 and expo(a, g / p[i], n) == 1) g /= p[i];
    }
    return g;
  }

  static order get(int n);
  static std::map<int, order> mp;
};

std::map<int, order> order::mp;
order order::get(int n){
  if (mp.find(n) == mp.end()) {
    mp.insert(std::make_pair(n, order(n)));
  }
  std::map<int, order>::const_iterator pos = mp.find(n);
  return pos->second;
}

int main() {
  int T;
  for (scanf("%d", &T); T > 0; --T) {
    int M, Q;
    scanf("%d%d", &M, &Q);
    for (int i=0; i < Q; ++i) {
      int A;
      scanf("%d", &A);
      assert(0 <= A and A < M);
      int n1 = fil(M, A);
      int n0 = M / n1;
      int c = 0;
      for (int a = A % n0; a; a = (long long) a * A % n0) ++c;
      c += order::get(n1)(A);
      printf("%d\n", c);
    }
  }
  return 0;
}
