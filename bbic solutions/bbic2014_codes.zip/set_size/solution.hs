
module Main where
import Control.Monad

fil n a = let d = gcd n a
          in  if d == 1 then n
              else fil (div n d) a

expo _ _ 0 = 1
expo m b 1 = mod b m
expo m b e = let a = let a = expo m b (div e 2)
                     in mod (a * a) m
             in  if (mod e 2) == 1 then mod (a * b) m else a

pfactors n = reverse (f n 2 [])
  where f n m acc =
          if n == 1 || m > n then acc
          else if m * m > n then (n : acc)
               else let p = head (filter (\k -> mod n k == 0) [m .. truncate (sqrt $ fromIntegral n)] ++ [n])
                    in  f (fil n p) (p + 1) (p:acc)

euler_totient n = foldl f n $ pfactors n where f n p = n - (div n p)

order n a = let e = expo n a
                f g p = if mod g p == 0 && e (div g p) == 1 then f (div g p) p else g
                g = euler_totient n
            in  foldl f g $ pfactors g

order_ n a = f (mod a n) where f x = if x == 0 then 0 else f (mod (x * a) n) + 1

f m a = let n' = fil m a
            n_ = div m n'
        in  order n' a + order_ n_ a

main = let readint s = read s :: Int
       in  getLine >>=
       \line -> replicateM (readint line) $ getLine >>=
                \line -> let [m, q] = map readint (words line)
                         in  replicateM q $ getLine >>=
                             \line -> print $ f m (readint line)
