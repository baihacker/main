
module Main where
import Control.Monad

uniq lst = foldl push [] lst where push l e = if elem e l then l else e : l

fil n a = let d = gcd n a
          in  if d == 1 then n
              else fil (div n d) a

expo _ _ 0 = 1
expo m b 1 = mod b m
expo m b e = let a = let a = expo m b (div e 2)
                     in mod (a * a) m
             in  if (mod e 2) == 1 then mod (a * b) m else a

pfactors n = reverse (f n 2 [])
  where f n m acc =
          if n == 1 || m > n then acc
          else if m * m > n then (n : acc)
               else let p = head (filter (\k -> mod n k == 0) [m .. truncate (sqrt $ fromIntegral n)] ++ [n])
                    in  f (fil n p) (p + 1) (p:acc)

pfactors_with ps n = let lst = filter (\x -> mod n x == 0) ps
                         lst' = pfactors $ foldl fil n lst
                     in  uniq (lst ++ lst')

euler_totient_with pf n = foldl f n $ pf n where f n p = n - (div n p)

order_with pf n a = let e = expo n a
                        f g p = if mod g p == 0 && e (div g p) == 1 then f (div g p) p else g
                        g = euler_totient_with pf n
                    in  foldl f g $ pf g

order_ n a = f (mod a n) where f x = if x == 0 then 0 else f (mod (x * a) n) + 1

ppp m = let ps = pfactors m in uniq $ concat (ps : [pfactors (p-1) | p <- ps])

f ps m a = let pf = pfactors_with ps
           in let n' = fil m a
                  n_ = div m n'
              in  order_with pf n' a + order_ n_ a

main = let readint s = read s :: Int
       in  getLine >>=
       \line -> replicateM (readint line) $ getLine >>=
                \line -> let [m, q] = map readint (words line)
                             ps = ppp m
                         in  replicateM q $ getLine >>= (print . (f ps m) . readint)
