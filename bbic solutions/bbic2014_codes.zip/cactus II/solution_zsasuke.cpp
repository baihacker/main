#include<iostream>
#include<cstring>
#include<cstdio>
#include<algorithm>
#include<vector>
using namespace std;
const int maxn=50000+5;
vector< vector<int> > cir[maxn];
vector<int> zz[maxn],e[maxn];
int dep[maxn];
bool vis[maxn];
int n,m;
int st[maxn*3],size,pos[maxn];
int dp[maxn][2],cal[maxn*2][2];
const int inf=1000000000;
void dfs(int cur,int f,int d)
{
	vis[cur]=1;
	dep[cur]=d;
	st[size++]=cur;
	pos[cur]=size-1;
	for(int i=0;i<zz[cur].size();i++)
	{
		int k=zz[cur][i];
		if(k!=f)
		{
		if(vis[k]==0)
		{
		st[size++]=e[cur][i];
		dfs(k,cur,d+1);
		size--;
		 dep[cur]=min(dep[cur],dep[k]);
    	}
    	else if(dep[k]<dep[cur])
    	{
	 	   vector<int> tep;
	 	   if(size-pos[k]>10000)
	 	   {
				fprintf(stderr,"error\n");
				exit(0);
			}
	 	   for(int j=pos[k];j<size;j++)
	 	    tep.push_back(st[j]);
	 	  tep.push_back(e[cur][i]);
	 	  dep[cur]=dep[k];
	 	  cir[k].push_back(tep);
	 	  tep.clear();
		} 
	    }     //if
	}
	size--;	
}
void proc(int ind,vector<int> &c,pair<int,int> &tep)
{

	cal[2][0]=dp[c[2]][0];
	cal[2][1]=dp[c[2]][1];
	for(int j=4;j<c.size();j+=2)
	{
		cal[j][0]=max(cal[j-2][0],cal[j-2][1])+dp[c[j]][0];
		cal[j][1]=cal[j-2][0]+c[j-1]+dp[c[j]][0];
		 	cal[j][1]=max(cal[j][1],dp[c[j]][1]+max(cal[j-2][0],cal[j-2][1]));
	}
	tep.first=max(cal[c.size()-2][0],cal[c.size()-2][1]);
	tep.second=cal[c.size()-2][0]+c[c.size()-1];
	cal[2][0]=-inf;
	cal[2][1]=c[1]+dp[c[2]][0];
	for(int j=4;j<c.size();j+=2)
	{
		cal[j][0]=max(cal[j-2][0],cal[j-2][1])+dp[c[j]][0];
		cal[j][1]=cal[j-2][0]+c[j-1]+dp[c[j]][0];
		 	cal[j][1]=max(cal[j][1],dp[c[j]][1]+max(cal[j-2][0],cal[j-2][1]));
	}
	int u=max(cal[c.size()-2][1],cal[c.size()-2][0]);
	tep.second=max(tep.second,u);
}
void dfs2(int cur,int f)
{
	dp[cur][0]=dp[cur][1]=0;
	vis[cur]=1;
	vector<pair<int,int> >ps;
	for(int i=0;i<cir[cur].size();i++)
	{
		for(int j=0;j<cir[cur][i].size();j+=2)
		  vis[cir[cur][i][j]]=1;
			for(int j=2;j<cir[cur][i].size();j+=2)
		      dfs2(cir[cur][i][j],-1);
		pair<int,int> d;
		proc(cur,cir[cur][i],d);
		ps.push_back(d);
	}
	for(int i=0;i<zz[cur].size();i++)
	{
		if(vis[zz[cur][i]]==0&&zz[cur][i]!=f)
		{
		dfs2(zz[cur][i],cur);
		pair<int,int>d;
		d.first=max(dp[zz[cur][i]][0],dp[zz[cur][i]][1]);
		d.second=dp[zz[cur][i]][0]+e[cur][i];
		ps.push_back(d);
		}
	}
	int sum=0,mat=inf;
	for( int i=0;i<ps.size();i++)
	{
		sum+=ps[i].first;
		mat=min(mat,ps[i].first-ps[i].second);
	}
	ps.clear();
	dp[cur][0]=sum;
	dp[cur][1]=sum-mat;
}
void init(int n)
{
	size=0;
	memset(vis,0,n+2);
	for(int i=0;i<n;i++)
	{
		cir[i].clear();
		zz[i].clear();
		e[i].clear();
	}
}
int main()
{
	int cas;
	scanf("%d",&cas);
	while(cas--)
	{
		scanf("%d%d",&n,&m);
		init(n);
		int a,b,c;
		for(int i=0;i<m;i++)
		{
			scanf("%d%d%d",&a,&b,&c);
			zz[a].push_back(b);
			zz[b].push_back(a);
			e[a].push_back(c);
			e[b].push_back(c);
		}
		dfs(0,-1,0);
		memset(vis,0,n+2);
		dfs2(0,-1);
		printf("%d\n",max(dp[0][0],dp[0][1]));
	}
	return 0;
}
