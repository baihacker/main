#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <algorithm>
#include <cassert>
#include <iostream>
using namespace std;

#define SI static inline
#define DEBUG
#ifdef DEBUG
#define MAKE_SURE(x) assert(x)
#else
#define MAKE_SURE(x) ((void)0)
#endif

// ͼ�ı�ʾ
const int maxn = 50005;
const int maxe = maxn * 8;

enum{DEL=5, CUT, CIRCLE};

struct Edge
{
  int to, next;
  int w, cid;
};

int adj[maxn];
Edge eg[maxe];int tope;
int curr_id[maxn], min_id[maxn], visited[maxn];
int special_edge[maxn];

SI void init(int n)
{
  fill(adj, adj+n, -1);
  fill(visited, visited+n, 0);
  fill(special_edge, special_edge, -1);
  tope= 0;
}

SI void _add_edge(int s, int t, int w)
{
  eg[tope].to = t, eg[tope].next = adj[s],
  eg[tope].w = w;
  adj[s] = tope++;
  MAKE_SURE(tope<=maxe);
}

SI void add_edge(int s, int t, int w)
{
  _add_edge(s, t, w), _add_edge(t, s, w);
}

int stk[maxe<<1], stop, next_id;
int dp[maxn][2];

void dfs(int curr, int pre)
{
  int where = stop;
  curr_id[curr] = min_id[curr] = ++next_id;
  stk[stop++] = curr;
  visited[curr] = 1;
  
  dp[curr][0] = dp[curr][1] = 0;
  int sum = 0, inc = 0;
  for (int i = adj[curr]; i != -1; i = eg[i].next)
  {
    const int to = eg[i].to;
    
    if (to == pre) continue;
    
    if (visited[to])
    {
      if (curr_id[to] < curr_id[curr])
      {
        special_edge[curr] = i;
      }
      min_id[curr] = min(min_id[curr], curr_id[to]);
    }
    else
    {
      stk[stop++] = i;
      dfs(to, curr);

      min_id[curr] = min(min_id[curr], min_id[to]);
      if (min_id[to] > curr_id[curr])
      {// ��
        MAKE_SURE(stop==where+3);
        stop -= 2;
        
        sum += max(dp[to][0], dp[to][1]);
        inc = max(inc, eg[i].w + dp[to][0] - max(dp[to][0], dp[to][1]));
      }
      else if (min_id[to] == curr_id[curr])
      {// ��
        int local_dp[4] = {0};
        int e = -1;
        while (stop - 1 > where)
        {
          const int last_e = e;
          const int v = stk[--stop];
          e = stk[--stop];
          if (last_e == -1)
          {
            int who = special_edge[v];
            MAKE_SURE(who != -1);
            local_dp[0] = dp[v][0];
            local_dp[1] = dp[v][1];
            local_dp[2] = -1000000000;
            local_dp[3] = eg[who].w + dp[v][0];
          }
          else
          {
            int next_dp[4] = {0};
            next_dp[0] = max(local_dp[0], local_dp[1]) + dp[v][0];
            next_dp[1] = max(max(local_dp[0], local_dp[1]) + dp[v][1], eg[last_e].w + dp[v][0] + local_dp[0]);
            next_dp[2] = max(local_dp[2], local_dp[3]) + dp[v][0];
            next_dp[3] = max(max(local_dp[2], local_dp[3]) + dp[v][1], eg[last_e].w + dp[v][0] + local_dp[2]);
            memcpy(local_dp, next_dp, sizeof next_dp);
          }
        }
        MAKE_SURE(stop == where+1);
        MAKE_SURE(e == i);
        
        const int a = max(local_dp[0], local_dp[1]);
        sum += a;
        int b = max(local_dp[2], local_dp[3]);
        int c = local_dp[0] + eg[e].w;
        inc = max(inc, max(b, c) - a);
      }
    }
  }
  dp[curr][0] = sum;
  dp[curr][1] = sum + inc;
}

int main()
{
  int cas; scanf("%d", &cas);
  MAKE_SURE(cas <= 15);
  while (cas--)
  {
    int n, e; scanf("%d%d", &n, &e);
    MAKE_SURE(n>=1&&n<=50000);
    MAKE_SURE(e>=0&&e<=200000);
    init(n);
    for (int i = 0; i < e; ++i)
    {
      int s, t, w; scanf("%d%d%d", &s, &t, &w);
      MAKE_SURE(s>=0&&s<n);
      MAKE_SURE(t>=0&&t<n);
      MAKE_SURE(w>=1&&w<=100);
      MAKE_SURE(s!=t);
      add_edge(s, t, w);
    }
    stop = 0;
    dfs(0, -1);
    printf("%d\n", max(dp[0][0], dp[0][1]));
  }
  return 0;
}
