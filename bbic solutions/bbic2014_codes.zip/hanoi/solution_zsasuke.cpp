#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
int in[40];
int s,x,y;
void hanoi(int n,int c,int to,int lef)
{
	if(n==1)
	{
		s=0;
		x=c;
		y=to;
		in[n-1]=to;
	}
	else
	{
		if(lef>(1<<(n-1))-1)
		{
			for(int i=0;i<n-1;i++)
			 in[i]=3-to-c;
			lef-=(1<<(n-1))-1;
			if(lef==1)
			{
				s=n-1;
				x=c;
				y=to;
				in[n-1]=to;
			}
			else
			{
				lef--;
				in[n-1]=to;
				hanoi(n-1,3-c-to,to,lef);
			}
			
		}
		else
		{
			in[n-1]=c;
			hanoi(n-1,c,3-c-to,lef);
		}		
	}
}
int main()
{
	int cas;
	scanf("%d",&cas);
	while(cas--)
	{
		int n,m;
		scanf("%d%d",&n,&m);
		hanoi(n,0,2,m);
		for(int i=0;i<n;i++)
		printf("%d",in[i]);
		printf(" %d %d %d\n",s,x,y);
	}
	return 0;
}
