#include <cstdio>
#include <cassert>
using namespace std;
static inline int Rint()
{
     struct X{ int dig[256]; X(){
     for(int i = '0'; i <= '9'; ++i) dig[i] = 1; dig['-'] = 1;
     }};
     static     X fuck;int s = 1, v = 0, c;
     for (;!fuck.dig[c = getchar()];);
     if (c == '-') s = 0; else if (fuck.dig[c]) v = c ^ 48;
     for (;fuck.dig[c = getchar()]; v = v * 10 + (c ^ 48));
     return s ? v : -v;
}
int main()
{
  int T = Rint();
  assert(T >= 1 && T <= 100000);
  while (T--)
  {
    const int N = Rint(), M = Rint();
    const int PN = 1 << N;
    assert(N >= 1 && N <= 30);
    assert(M >= 1 && M < PN);
    int idx = 0, s = -1, t = -1;
    while ((M&(1<<idx)) == 0) ++idx;
    char ans[32];
    for (int from = 0, to = 2, i = N - 1; i >= 0; --i)
    {
      const int temp = 3 - from - to;
      if (M&(1<<i))
      {
        ans[i] = to + '0';
        if (i == idx)
        {
          s = from, t = to;
        }
        from = temp;
      }
      else
      {
        ans[i] = from + '0';
        to = temp;
      }
    }
    ans[N] = 0;
    printf("%s %d %d %d\n", ans, idx, s, t);
  }
}