#include <cstdio>
#include <cassert>
#include <cstring>
#include <algorithm>
#include <numeric>
#include <iostream>
#include <ctime>
using namespace std;
static inline int Rint()
{
     struct X{ int dig[256]; X(){
     for(int i = '0'; i <= '9'; ++i) dig[i] = 1; dig['-'] = 1;
     }};
     static     X fuck;int s = 1, v = 0, c;
     for (;!fuck.dig[c = getchar()];);
     if (c == '-') s = 0; else if (fuck.dig[c]) v = c ^ 48;
     for (;fuck.dig[c = getchar()]; v = v * 10 + (c ^ 48));
     return s ? v : -v;
}
typedef long long int64;
const int mod = 1000000007;
const int maxn = 50010;

static inline int add(int a, int b)
{a+=b;if(a>=mod)a-=mod;return a;}

int tree[maxn<<2];
int flag[maxn<<2][5];
int value[maxn+100][5];
int sum[maxn+100][5];
int L[10], C[10];
int N, Q;

static inline void init()
{
  for (int i = 1; i <= 5; ++i)
  value[i][i-1] = 1;
  for (int i = 6; i < N + 50; ++i)
  for (int j = 0; j < 5; ++j)
  {
    int s = 0;
    for (int k = 1; k <= 5; ++k)
    s = add(s, (int64)value[i-k][j] * C[k] % mod);
    value[i][j] = s;
  }
  for (int i = 1; i < N + 50; ++i)
  for (int j = 0; j < 5; ++j)
  sum[i][j] = add(sum[i-1][j], value[i][j]);
}

static inline int value_at(int* coe, int id)
{
  int ret = 0;
  for (int i = 0; i < 5; ++i)
  ret = add(ret, (int64)value[id][i] * coe[i] % mod);
  return ret;
}

static inline int sum_at(int* coe, int id)
{
  int ret = 0;
  for (int i = 0; i < 5; ++i)
  ret = add(ret, (int64)sum[id][i] * coe[i] % mod);
  return ret;
}

static inline int should_push(int* coe)
{
  for (int i = 0; i < 5; ++i)
  if (coe[i] > 0) return 1;
  return 0;
}

void update(const int root, const int l, const int r, int a, int b, int* coe)
{
  if (l == a && r == b)
  {
    tree[root] = add(tree[root], sum_at(coe, b-a+1));
    for (int i = 0; i < 5; ++i)
    flag[root][i] = add(flag[root][i], coe[i]);
    return;
  }
  const int lc = root << 1, rc = lc + 1, mid = l + r >> 1;
  if (should_push(flag[root]))
  {
    for (int i = 0; i < 5; ++i)
    flag[lc][i] = add(flag[lc][i], flag[root][i]);
    tree[lc] = add(tree[lc], sum_at(flag[root], mid-l+1));
    
    int new_coe[5];
    for (int i = 0; i < 5; ++i)
    new_coe[i] = value_at(flag[root], mid+2-l+i);
    for (int i = 0; i < 5; ++i)
    flag[rc][i] = add(flag[rc][i], new_coe[i]);
    tree[rc] = add(tree[rc], sum_at(new_coe, r-mid));
    memset(flag[root], 0, sizeof (flag[root]));
  }
  if (b <= mid) update(lc, l, mid, a, b, coe);
  else if (a > mid) update(rc, mid+1, r, a, b, coe);
  else
  {
    update(lc, l, mid, a, mid, coe);
    int new_coe[5];
    for (int i = 0; i < 5; ++i)
    new_coe[i] = value_at(coe, mid+2-a+i);
    update(rc, mid+1, r, mid+1, b, new_coe);
  }
  tree[root] = add(tree[lc], tree[rc]);
}

int query(int root, int l, int r, int a, int b)
{
  if (l == a && r == b)
  {
    return tree[root];
  }
  const int lc = root << 1, rc = lc + 1, mid = l + r >> 1;
  if (should_push(flag[root]))
  {
    for (int i = 0; i < 5; ++i)
    flag[lc][i] = add(flag[lc][i], flag[root][i]);
    tree[lc] = add(tree[lc], sum_at(flag[root], mid-l+1));
    
    int new_coe[5];
    for (int i = 0; i < 5; ++i)
    new_coe[i] = value_at(flag[root], mid+2-l+i);
    for (int i = 0; i < 5; ++i)
    flag[rc][i] = add(flag[rc][i], new_coe[i]);
    tree[rc] = add(tree[rc], sum_at(new_coe, r-mid));
    memset(flag[root], 0, sizeof (flag[root]));
  }
  if (b <= mid) return query(lc, l, mid, a, b);
  else if (a > mid) return query(rc, mid+1, r, a, b);
  else
  {
    int s0 = query(lc, l, mid, a, mid);
    int s1 = query(rc, mid+1, r, mid+1, b);
    return add(s0, s1);
  }
}

int data[3][5][5];

// ����n�ʼ���5��
void cal(int n, int* out)
{
  int (*m)[5] = data[0];
  int (*r)[5] = data[1];
  int (*t)[5] = data[2];
  for (int i = 0; i < 5; ++i)
  r[i][0] = L[5-i];
  memset(m, 0, sizeof data[0]);
  for (int i = 0; i < 5; ++i)
  m[0][i] = C[i+1];
  for (int i = 1; i < 5; ++i)
  m[i][i-1] = 1;
  for (--n; n; n >>= 1)
  {
    if (n&1)
    {
      for (int i = 0; i < 5; ++i)
      {
        int64 s = 0;
        for (int k = 0; k < 5; ++k)
        s += (int64)m[i][k] * r[k][0] % mod;
        t[i][0] = s % mod;
      }
      swap(r, t);
    }
    for (int i = 0; i < 5; ++i)
    for (int j = 0; j < 5; ++j)
    {
      int64 s = 0;
      for (int k = 0; k < 5; ++k)
      s += (int64)m[i][k] * m[k][j] % mod;
      t[i][j] = s % mod;
    }
    swap(m, t);
  }
  for (int i = 0; i < 5; ++i)
  out[i] = r[4-i][0];
}

int main()
{
  int T = Rint();
  assert(T <= 20);
  const int case_all = T;
  int small_case = 0;
  while (T--)
  {
    for (int i = 1; i <= 5; ++i)
    L[i] = Rint(), assert(L[i] >= 1 && L[i] <= 1000000000);
    for (int i = 1; i <= 5; ++i)
    C[i] = Rint(), assert(C[i] >= 1 && C[i] <= 1000000000);
    N = Rint(), Q = Rint();
    assert(N >= 1 && N <= 50000);
    assert(Q >= 1 && Q <= 50000);
    if (N <= 1000 && Q <= 1000) ++small_case;
    init();
    memset(tree, 0, sizeof(tree[0]) * (N*4+2));
    memset(flag, 0, sizeof(flag[0]) * (N*4+2));
    while (Q--)
    {
      int cmd = Rint(), l = Rint(), r = Rint();
      //cerr << cmd << " " << l << " " << r << " " << N << endl;
      assert(l >= 1 && l <= N);
      assert(r >= l && r <= N);
      if (cmd == 1)
      {
        printf("%d\n", query(1, 1, N, l, r));
      }
      else
      {
        int s = Rint();
        assert(s >= 1 && s <= 1000000000);
        int coe[5];
        cal(s, coe);
        update(1, 1, N, l, r, coe);
      }
    }
  }
  assert(small_case * 10 >= case_all * 9);
  //cerr << clock() << endl;
  return 0;
}