#include <cstdio>
#include <cassert>
#include <cstring>
#include <algorithm>
#include <numeric>
#include <iostream>
#include <ctime>
using namespace std;
static inline int Rint()
{
     struct X{ int dig[256]; X(){
     for(int i = '0'; i <= '9'; ++i) dig[i] = 1; dig['-'] = 1;
     }};
     static     X fuck;int s = 1, v = 0, c;
     for (;!fuck.dig[c = getchar()];);
     if (c == '-') s = 0; else if (fuck.dig[c]) v = c ^ 48;
     for (;fuck.dig[c = getchar()]; v = v * 10 + (c ^ 48));
     return s ? v : -v;
}
typedef long long int64;
const int mod = 1000000007;
const int maxn = 50010;

static inline int add(int a, int b)
{a+=b;if(a>=mod)a-=mod;return a;}


int L[10], C[10];
int N, Q;


int64 X[1050];
int64 SEQ[1050];
int data[3][5][5];

// ����n�ʼ���5��
void cal(int n, int* out)
{
	int (*m)[5] = data[0];
	int (*r)[5] = data[1];
	int (*t)[5] = data[2];
	for (int i = 0; i < 5; ++i)
	r[i][0] = L[5-i];
	memset(m, 0, sizeof data[0]);
	for (int i = 0; i < 5; ++i)
	m[0][i] = C[i+1];
	for (int i = 1; i < 5; ++i)
	m[i][i-1] = 1;
	for (--n; n; n >>= 1)
	{
		if (n&1)
		{
			for (int i = 0; i < 5; ++i)
			{
				int64 s = 0;
				for (int k = 0; k < 5; ++k)
				s += (int64)m[i][k] * r[k][0] % mod;
				t[i][0] = s % mod;
			}
			swap(r, t);
		}
		for (int i = 0; i < 5; ++i)
		for (int j = 0; j < 5; ++j)
		{
			int64 s = 0;
			for (int k = 0; k < 5; ++k)
			s += (int64)m[i][k] * m[k][j] % mod;
			t[i][j] = s % mod;
		}
		swap(m, t);
	}
	for (int i = 0; i < 5; ++i)
	out[i] = r[4-i][0];
}

int main()
{
	int T = Rint();
  assert(T <= 20);
  const int case_all = T;
  int small_case = 0;
	while (T--)
	{
		for (int i = 1; i <= 5; ++i)
		L[i] = Rint(), assert(L[i] >= 1 && L[i] <= 1000000000);
		for (int i = 1; i <= 5; ++i)
		C[i] = Rint(), assert(C[i] >= 1 && C[i] <= 1000000000);
		N = Rint(), Q = Rint();
		assert(N >= 1 && N <= 50000);
		assert(Q >= 1 && Q <= 50000);
    if (N <= 1000 && Q <= 1000) ++small_case;
		memset(X, 0, sizeof X);
		while (Q--)
		{
			int cmd = Rint(), l = Rint(), r = Rint();
			cerr << cmd << " " << l << " " << r << " " << N << endl;
			assert(l >= 1 && l <= N);
			assert(r >= l && r <= N);
			if (cmd == 1)
			{
        int64 s = 0;
        for (int i = l; i <= r; ++i)
        s += X[i];
				printf("%lld\n", s % mod);
			}
			else
			{
				int s = Rint();
				assert(s >= 1 && s <= 1000000000);
				int coe[5];
				cal(s, coe);
				for (int i = 1; i <= 5; ++i)
        SEQ[i] = coe[i-1];
        for (int i = 6; i <= 100; ++i)
        {
          int64 s = 0;
          for (int j = 1; j <= 5; ++j)
          s += SEQ[i-j] * C[j] % mod;
          SEQ[i] = s % mod;
        }
        
        for (int i = l, j = 1; i <= r; ++i, ++j)
        {
          X[i] = add(X[i], SEQ[j]);
          assert(j <= 100);
        }
			}
		}
	}
  assert(small_case * 10 >= case_all * 9);
	//cerr << clock() << endl;
	return 0;
}