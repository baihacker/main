#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <cassert>
#include <ctime>
using namespace std;
typedef long long int64;
static inline int Rint()
{
  struct X{ int dig[256]; X(){
  for(int i = '0'; i <= '9'; ++i) dig[i] = 1; dig['-'] = 1;
  }};
  static  X fuck;int s = 1, v = 0, c;
  for (;!fuck.dig[c = getchar()];);
  if (c == '-') s = 0; else if (fuck.dig[c]) v = c ^ 48;
  for (;fuck.dig[c = getchar()]; v = v * 10 + (c ^ 48));
  return s ? v : -v;
}

int pre[17][1<<16];
int inv[17][1<<16];
int p5[17][1<<16];
int bc[1<<17];

void init()
{
  for (int i = 1; i <= 16; ++i)
  bc[1<<i] = i;
  for (int c = 3; c <= 16; ++c)
  {
    const int mod = 1 << c;
    const int mask = mod - 1;
    const int cnt = 1 << c - 2;
    for (int i = 0, v = 1 & mask; i < cnt; ++i)
    {
      pre[c][v] = i;
      inv[c][v] = cnt - i & (cnt-1);
      
      pre[c][mod-v] = i;
      inv[c][mod-v] = cnt - i & (cnt-1);
      
      p5[c][i] = v;
      
      assert(v != mod - v);
      
      v = v * 5 & mask;
    }
    p5[c][cnt] = 1;
    #if 0
    int s = 0;
    for (int i = 0; i < mod; ++i)
    if (pre[c][i] == 0) ++s;
    cerr << s - 2 << " " << mod / 2 << endl;
    for (int i = 0, v = 1 & mask; i < cnt; ++i)
    {
      int test = (int64)v * p5[c][inv[c][v]] % mod;
      assert(test == 1);
      test = (int64)(mod-v) * (mod-p5[c][inv[c][v]]) % mod;
      assert(test == 1);
      v = v * 5 & mask;
    }
    #endif
  }
}

static inline int solve_one(int a, int b, int c)
{
  // a*x=b mod(1<<c)
  // gcd(a, 1<<c) = 1
  const int mod = 1 << c;
  const int mask = mod - 1;
  
  if (c <= 2)
  {
    for (int x = 0; x < mod; ++x)
    if ((x * a & mask) == b) return x;
    return -1;
  }
  
  int where = pre[c][a];
  int s = a % 4 == 1 ? 1 : -1;
  if (s == 1)
  {
    int ans = (int64)p5[c][inv[c][a]] * b & mask;
    //cerr << a << " " << b << " " << c << " " << ans << endl;
    assert((int64)a*ans%mod==b);
    return ans;
  }
  else
  {
    int ans = (int64)(mod - p5[c][inv[c][a]]) * b & mask;
    //cerr << a << " " << b << " " << c << " " << ans << endl;
    assert((int64)a*ans%mod==b);
    return ans;
  }
  return -1;
}

int solve(unsigned int a, unsigned int b, unsigned int c)
{
  const unsigned int mod = 1 << c;
  const unsigned int mask = mod - 1;
  
  if (c == 1)
  {
    return b == 0 ? -1 : 0;
  }
  
  if (c == 2)
  {
    switch (a)
    {
      case 0:  assert(0);
      case 1:  if (b == 1) return 0;
               return -1;
      case 2:  if (b == 1) return 0;
           if (b == 2) return 1;
           if (b == 0) return 2;
           return -1;
      case 3:  if (b == 1) return 0;
           if (b == 3) return 1;
           return -1;
    }
  }
  
  if ((a&1) == 0)
  {
    unsigned int now = 1;
    int x = 0;
    do
    {
      if (now == b) return x;
      now = now * a & mask;
      ++x;
    } while (now != 0);
    if (now == b) return x;
    return -1;
  }
  
  if ((b&1) == 0)
  {
    return -1;
  }
  // a and b are all odd
  int ca = a % 4 == 1 ? 1 : -1, va = pre[c][a];
  int cb = b % 4 == 1 ? 1 : -1, vb = pre[c][b];
  // a = ca * 5 ^ va
  // b = cb * 5 ^ vb
  // (ca * 5 ^ va) ^ x = cb * 5 ^ vb
  // ca^x * 5 ^ va*x = cb * 5 ^ vb
  
  const int L = mod >> 2;
  // va*x = vb mod L
  if (va == 0)
  {
    if (ca > 0)
    {
      return vb == 0 && cb > 0 ? 0 : -1;
    }
    else
    {
      if (vb == 0 && cb > 0) return 0;
      return vb == 0 && cb < 0 ? 1 : -1;
    }
  }

  // va : [1, L)
  // vb : [0, L)
  
  if (ca == 1)
  {
    if (cb == -1) return -1;
    // va*x = vb mod L
    int d = __gcd(L, va);
    if (vb % d) return -1;
    return solve_one(va/d, vb/d, bc[L/d]);
  }
  if (cb == 1)
  {
    // x is even
    // va*x = vb mod L
    int d = __gcd(L, va);
    if (vb % d) return -1;
    int ans = solve_one(va/d, vb/d, bc[L/d]);
    return ans & 1 ? -1 : ans;
  }
  else
  {
    // x is odd
    // va*x = vb mod L
    int d = __gcd(L, va);
    if (vb % d) return -1;
    int ans = solve_one(va/d, vb/d, bc[L/d]);
    return ans & 1 ? ans : -1;
  }
}

void verify(int a, int x, int b, int c)
{
  const int mod = 1 << c;
  int64 r = 1;
  int64 m = a;
  for (int n = x; n; n >>= 1)
  {
    if (n&1) r = r * m % mod;
    m = m * m % mod;
  }
  puts(r == b ? "YES" : "NO");
}

int main()
{
  init();
  int T = Rint();
  assert(T <= 300000);
  for (int q = T; q --; )
  {
    const int a = Rint(), b = Rint(), c = Rint();
    
    const int mod = 1 << c;
    assert(c >= 1 && c <= 16);
    assert(a >= 1 && a < mod);
    assert(b >= 0 && b < mod);
    int ans = solve(a, b, c);
    //verify(a, ans, b, c);
    printf("%d\n", ans);
  }
  //cerr << clock() << endl;
  return 0;
}