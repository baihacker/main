
module Main where
import Control.Monad
import qualified Data.Map as Map(fromList, lookup)

euclid _ 0 = (1, 0)
euclid a b = let (y, x) = euclid b (mod a b)
             in  (x, y - (div a b) * x)

associate a n = let (x, _) = euclid a n
                in mod ((mod x n) + n) n

expo _ _ 0 = 1
expo m b 1 = mod b m
expo m b e = let a = let a = expo m b (div e 2)
                     in mod (a * a) m
             in  if (mod e 2) == 1 then mod (a * b) m else a

linear_eq n a b = let d = gcd a n
                  in  if mod b d /= 0 then []
                      else let n' = div n d
                               a' = associate (div a d) n'
                               x = mod ((div b d) * a') n'
                           in take d [x, x + n']

e2 = expo 2146483647 2

dlog2_5_table m = let n' = e2 (m - 2)
                      e = expo (n' * 4) 5
                  in  Map.fromList [(e i, i) | i <- [0 .. (n' - 1)]]

dlog2_5_tables = [(m, dlog2_5_table m) | m <- [4 .. 16]]

dlog2_5 m a =
  let Just table = lookup m dlog2_5_tables
  in  let Just i = Map.lookup a table in i

dlog2 a b c = let dlog = dlog2_5 c . (\x -> if mod x 4 == 1 then x else n - x) where n = e2 c
              in  take 2 (linear_eq (e2 (c - 2)) (dlog a) (dlog b))

solve line = let [a, b, c] = map read (words line) :: [Int]
             in  let candidates = if c > 3 && (mod a 2) == 1 && (mod b 2) == 1
                                  then dlog2 a b c
                                  else [0 .. c]
                 in  let lst = filter (\x -> e x == b) candidates where e = expo (e2 c) a
                     in  if null lst then -1 else head lst

main = getLine >>= \line -> replicateM (read line :: Int) $
                            getLine >>= (\line -> print $ solve line)
