#include <cstdio>
#include <iostream>
#include <cstring>
#include <cmath>
#include <algorithm>
using namespace std;
typedef unsigned int ll;

const int small = 5;
int T;
int a, b, c;
int mod;
int dp[17][1<<16];

void Extended_Euclid(int a, int b, int &d, int &x, int &y) //ax + by = gcd(a, b)
{
	if (!b) {d=a; x=1; y=0;}
	else {Extended_Euclid(b,a%b,d,y,x); y-=x*(a/b);}
}

int Modular_Linear_Equation(int a, int b, int n) //ax = b mod n
{
	int x,y,e,d;
	Extended_Euclid(a,n,d,x,y);
	if (b % d) return -1;
	e = (b/d * x) % n + n;
	return e % (n/d);
}

void init()
{
    for (int i=small;i<=16;i++)
    {
        int tot = 1 << i;
        dp[i][1] = dp[i][tot-1] = 0;
        ll t = 1;
        for (int j=1;j<(tot>>2);j++)
        {
            t = t * 5 % tot;
            dp[i][t] = dp[i][tot-t] = j;
        }
    }
}

int solve()
{
    if (b == 1) return 0;
    if (b == a) return 1;
    if ((a-b) % 2 != 0) return -1;

    mod = 1 << c;
    if (a % 2 == 0 || c < small)
    {
        ll t = 1;
        for (int i=1;i<mod;i++)
        {
            t = t * a % mod;
            if (t == b) return i;
            if (t == 0) break;
        }
        return -1;
    }

    int aa = dp[c][a], bb = dp[c][b];
    bool fa = a % 4 == 1 ? 0 : 1;
    bool fb = b % 4 == 1 ? 0 : 1;
    //cout << "test: " << aa << " " << bb << endl;

    if (aa == 0)
    {
        if (bb == 0)
        {
            if (fb == 0) return 0;
            else if (fa == 1) return 1;
            else return -1;
        }
        else return -1;
    }

    int x = Modular_Linear_Equation(aa, bb, mod >> 2);
    if (fa == 0)
    {
        if (fb == 0)
            return x;
        else return -1;
    }
    if (fb == 0)
    {
        if (x % 2 == 0)
            return x;
    }
    else
    {
        if (x % 2 == 1)
            return x;
    }

    return -1;
}

int main()
{
    init();
    scanf("%d", &T);
    while (T--)
    {
        scanf("%d%d%d", &a, &b, &c);
        printf("%d\n", solve());
    }
    return 0;
}
