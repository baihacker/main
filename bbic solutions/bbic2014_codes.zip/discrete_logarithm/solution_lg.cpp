
#include <cassert>
#include <cstdio>
#include <map>
using namespace std;

int gcd(int a, int b) {
  return b ? gcd(b, a % b) : a;
}

int euclid(int a, int b, int &x, int &y) {
  if (b == 0) {
    x = 1;
    y = 0;
    return a;
  }
  else {
    int d = euclid(b, a % b, y, x);
    y -= a / b * x;
    return d;
  }
}

int inverse(int a, int n) {
  int x, y;
  euclid(a, n, x, y);
  return (x % n + n) % n;
}

int highbit(int x) {
  for (; x & (x - 1); x &= x - 1);
  return x;
}

struct expo{
  const int m;
  expo(int m): m(m) {}

  int operator()(int b, int e) const {
    int a = 1;
    for (int l=highbit(e); l; l >>= 1) {
      a = (long long) a * a % m;
      if (l & e) a = (long long) a * b % m;
    }

    return a;
  }
};

struct dlog2_5{
  const int m;
  const int n;
  const expo e;
  int H, L;
  map<int, int> ind;
  dlog2_5(int m): m(m), n(1 << m), e(n) {
    assert(m > 3);
    assert(n > 0);

    int l = (m - 2) >> 1;
    int h = (m - 2) - l;
    H = 1 << h;
    L = 1 << l;

    int g = e(5, L);
    int a = 1;
    for (int i=0; i < H; ++i) {
      ind[a] = i << l;
      a = (long long) a * g % n;
    }
  }

  int operator()(int a) {
    assert(a % 4 == 1);
    int g = e(5, (1 << (m - 2)) - 1);
    for (int i=0; i < L; ++i) {
      map<int, int>::iterator pos = ind.find(a);
      if (pos != ind.end()) return i + pos->second;
      a = (long long) a * g % n;
    }
    assert(false);
    return -1;
  }
};

struct xrange{
  const int d;
  int n;
  int a;
  xrange(int a, int n, int d): a(a), n(n), d(d) {}

  bool empty() { return n <= 0; }

  int operator*() {
    n -= 1;
    int x = a;
    a += d;
    return x;
  }

};

struct linear_eq {
  const int n;
  linear_eq(int n): n(n) {}

  xrange operator()(int a, int b) {
    int d = gcd(a, n);
    if (b % d) return xrange(0, 0, 0);
    int n_ = n / d;
    return xrange((long long) b / d * inverse(a / d, n_) % n_,
                  d, n_);
  }
};

map<int, dlog2_5*> dlog2_5_;

int f(int a, int b, int c)
{
  int n = 1 << c;
  expo e(n);
  if (c > 3 and a % 2 == 1 and b % 2 == 1) {
    if (dlog2_5_.find(c) == dlog2_5_.end()) {
      dlog2_5_[c] = new dlog2_5(c);
    } 
    dlog2_5 dlog = *dlog2_5_[c];

    int s = dlog(a % 4 == 1 ? a : n - a);
    int t = dlog(b % 4 == 1 ? b : n - b);
    xrange sol = linear_eq(1 << (c - 2))(s, t);
    for (int i=0; i < 2; ++i) {
      if (sol.empty()) break;
      int x = *sol;
      if (e(a, x) == b) return x;
    }
  }
  else {
    for (int i=0; i <= c; ++i) {
      if (e(a, i) == b) return i;
    }
  }
  return -1;
}

int main()
{
  int T;
  for (scanf("%d", &T); T > 0; --T) {
    int a, b, c;
    scanf("%d%d%d", &a, &b, &c);
    printf("%d\n", f(a, b, c));
  }
  return 0;
}
