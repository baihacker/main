#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <cassert>
#include <ctime>
using namespace std;

typedef long long int64;
static inline int Rint()
{
	struct X{ int dig[256]; X(){
	for(int i = '0'; i <= '9'; ++i) dig[i] = 1; dig['-'] = 1;
	}};
	static 	X fuck;int s = 1, v = 0, c;
	for (;!fuck.dig[c = getchar()];);
	if (c == '-') s = 0; else if (fuck.dig[c]) v = c ^ 48;
	for (;fuck.dig[c = getchar()]; v = v * 10 + (c ^ 48));
	return s ? v : -v;
}

int bf(int a, int b, int c)
{
	const int mod = 1 << c;
	const int mask = mod - 1;
	unsigned int now = 1;
	int x = 0;
	
	for (int x = 0; x < mod; ++x)
	{
		if (now == b) return x;
		now = now * a & mask;
	}

	return -1;
}

int main()
{
	for (int q = Rint(); q --; )
	{
		const int a = Rint(), b = Rint(), c = Rint();
		
		const int mod = 1 << c;
		assert(c >= 1 && c <= 16);
		assert(a >= 1 && a < mod);
		assert(b >= 0 && b < mod);
		int ans = bf(a, b, c);
		//verify(a, ans, b, c);
		printf("%d\n", ans);
	}
	//cerr << clock() << endl;
	return 0;
}